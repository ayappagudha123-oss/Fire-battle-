require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const crypto = require('node:crypto');
const path = require('node:path');
const db = require('./db');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const SESSION_SECRET = process.env.SESSION_SECRET || 'dev-only-change-me-before-deployment';
const isProd = process.env.NODE_ENV === 'production';

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '..', 'public')));

const sessions = new Map(); // Phase 1 starter: in-memory sessions; use persistent server-side sessions for multi-instance production.
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 15, standardHeaders: true, legacyHeaders: false });
const sign = (value) => crypto.createHmac('sha256', SESSION_SECRET).update(value).digest('hex');
function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { userId, expires: Date.now() + 7 * 24 * 60 * 60 * 1000 });
  return token + '.' + sign(token);
}
function getUser(req) {
  const raw = req.cookies.fb_session;
  if (!raw) return null;
  const [token, signature] = raw.split('.');
  if (!token || !signature || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(sign(token)))) return null;
  const session = sessions.get(token);
  if (!session || session.expires < Date.now()) { sessions.delete(token); return null; }
  return db.prepare('SELECT id,email,username,role,in_game_name,free_fire_uid,suspended,created_at FROM users WHERE id=?').get(session.userId) || null;
}
function requireAuth(req, res, next) {
  const user = getUser(req);
  if (!user) return res.status(401).json({ error: 'Please log in to continue.' });
  if (user.suspended) return res.status(403).json({ error: 'This account is suspended.' });
  req.user = user; next();
}
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) return res.status(403).json({ error: 'You do not have permission for this action.' });
    next();
  };
}
function audit(actorId, action, entityType, entityId, details = '') {
  db.prepare('INSERT INTO audit_logs(actor_id,action,entity_type,entity_id,details) VALUES(?,?,?,?,?)')
    .run(actorId || null, action, entityType, entityId || null, details);
}
function validEmail(s) { return typeof s === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s) && s.length <= 254; }
function safeText(s, max = 180) { return typeof s === 'string' ? s.trim().slice(0, max) : ''; }

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'Fire Battle', phase: 1 }));
app.get('/api/me', (req, res) => {
  const user = getUser(req);
  if (!user) return res.json({ user: null });
  res.json({ user });
});

app.post('/api/auth/register', authLimiter, (req, res) => {
  const email = safeText(req.body.email, 254).toLowerCase();
  const username = safeText(req.body.username, 32);
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (!validEmail(email) || username.length < 3 || password.length < 10) {
    return res.status(400).json({ error: 'Enter a valid email, a username of at least 3 characters, and a password of at least 10 characters.' });
  }
  if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) return res.status(409).json({ error: 'An account with that email already exists.' });
  const hash = bcrypt.hashSync(password, 12);
  const result = db.prepare('INSERT INTO users(email,username,password_hash) VALUES(?,?,?)').run(email, username, hash);
  const token = createSession(Number(result.lastInsertRowid));
  res.cookie('fb_session', token, { httpOnly: true, sameSite: 'lax', secure: isProd, maxAge: 7 * 86400000, path: '/' });
  audit(Number(result.lastInsertRowid), 'register', 'user', Number(result.lastInsertRowid));
  res.status(201).json({ user: getUser(reqWithCookie(req, token)) });
});
function reqWithCookie(req, token) { return { ...req, cookies: { ...req.cookies, fb_session: token } }; }

app.post('/api/auth/login', authLimiter, (req, res) => {
  const email = safeText(req.body.email, 254).toLowerCase();
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: 'Email or password is incorrect.' });
  if (user.suspended) return res.status(403).json({ error: 'This account is suspended.' });
  const token = createSession(user.id);
  res.cookie('fb_session', token, { httpOnly: true, sameSite: 'lax', secure: isProd, maxAge: 7 * 86400000, path: '/' });
  audit(user.id, 'login', 'user', user.id);
  res.json({ user: { id:user.id, email:user.email, username:user.username, role:user.role } });
});
app.post('/api/auth/logout', (req, res) => {
  const raw = req.cookies.fb_session;
  if (raw) sessions.delete(raw.split('.')[0]);
  res.clearCookie('fb_session', { httpOnly: true, sameSite: 'lax', secure: isProd, path: '/' });
  res.json({ ok: true });
});

app.get('/api/tournaments', (req, res) => {
  const status = safeText(req.query.status, 20);
  const mode = safeText(req.query.mode, 10);
  let sql = `SELECT t.*, (SELECT COUNT(*) FROM registrations r WHERE r.tournament_id=t.id) AS registered_count
             FROM tournaments t WHERE 1=1`;
  const args = [];
  if (['Upcoming','Open','Full','Live','Completed','Cancelled'].includes(status)) { sql += ' AND t.status=?'; args.push(status); }
  if (['Solo','Duo','Squad'].includes(mode)) { sql += ' AND t.mode=?'; args.push(mode); }
  sql += ' ORDER BY t.starts_at ASC LIMIT 100';
  res.json({ tournaments: db.prepare(sql).all(...args) });
});
app.get('/api/tournaments/:id', (req, res) => {
  const t = db.prepare(`SELECT t.*, (SELECT COUNT(*) FROM registrations r WHERE r.tournament_id=t.id) AS registered_count
    FROM tournaments t WHERE t.id=?`).get(Number(req.params.id));
  if (!t) return res.status(404).json({ error: 'Tournament not found.' });
  const matches = db.prepare('SELECT id,round_name,starts_at,map_name,status,credentials_release_at FROM matches WHERE tournament_id=? ORDER BY starts_at').all(t.id);
  const leaderboard = db.prepare(`SELECT u.username, u.in_game_name, SUM(rs.kills) kills,
    SUM(rs.kills) kill_points,
    SUM(CASE rs.placement WHEN 1 THEN 12 WHEN 2 THEN 9 WHEN 3 THEN 6 WHEN 4 THEN 4 WHEN 5 THEN 2 WHEN 6 THEN 1 ELSE 0 END) placement_points,
    COUNT(rs.id) matches_played,
    SUM(rs.kills + CASE rs.placement WHEN 1 THEN 12 WHEN 2 THEN 9 WHEN 3 THEN 6 WHEN 4 THEN 4 WHEN 5 THEN 2 WHEN 6 THEN 1 ELSE 0 END) total_points
    FROM result_submissions rs JOIN matches m ON m.id=rs.match_id JOIN users u ON u.id=rs.user_id
    WHERE m.tournament_id=? AND rs.status='Approved' GROUP BY u.id ORDER BY total_points DESC, kills DESC`).all(t.id);
  res.json({ tournament: t, matches, leaderboard });
});
app.post('/api/tournaments/:id/register', requireAuth, (req, res) => {
  const tournamentId = Number(req.params.id);
  const run = db.transaction(() => {
    const t = db.prepare('SELECT * FROM tournaments WHERE id=?').get(tournamentId);
    if (!t) throw Object.assign(new Error('Tournament not found.'), { status: 404 });
    if (t.status !== 'Open' || new Date(t.registration_deadline).getTime() <= Date.now()) throw Object.assign(new Error('Registration is closed.'), { status: 409 });
    const count = db.prepare('SELECT COUNT(*) n FROM registrations WHERE tournament_id=?').get(tournamentId).n;
    if (count >= t.slot_limit) throw Object.assign(new Error('Tournament is full.'), { status: 409 });
    db.prepare('INSERT INTO registrations(tournament_id,user_id,team_name) VALUES(?,?,?)').run(tournamentId, req.user.id, safeText(req.body.teamName, 50));
    if (count + 1 >= t.slot_limit) db.prepare("UPDATE tournaments SET status='Full' WHERE id=?").run(tournamentId);
  });
  try { run(); audit(req.user.id, 'register_tournament', 'tournament', tournamentId); res.status(201).json({ ok: true, message: 'Registration successful.' }); }
  catch (e) { res.status(e.status || (String(e.code).includes('UNIQUE') ? 409 : 400)).json({ error: String(e.code).includes('UNIQUE') ? 'You are already registered.' : (e.message || 'Could not register.') }); }
});
app.get('/api/me/registrations', requireAuth, (req, res) => {
  res.json({ registrations: db.prepare(`SELECT t.id,t.name,t.mode,t.starts_at,t.status,r.registered_at,r.team_name
    FROM registrations r JOIN tournaments t ON t.id=r.tournament_id WHERE r.user_id=? ORDER BY t.starts_at`).all(req.user.id) });
});

app.get('/api/matches/:id/room', requireAuth, (req, res) => {
  const match = db.prepare(`SELECT m.*, t.id tournament_id FROM matches m JOIN tournaments t ON t.id=m.tournament_id WHERE m.id=?`).get(Number(req.params.id));
  if (!match) return res.status(404).json({ error: 'Match not found.' });
  const staff = ['admin','moderator'].includes(req.user.role);
  const registered = !!db.prepare('SELECT 1 FROM registrations WHERE tournament_id=? AND user_id=?').get(match.tournament_id, req.user.id);
  if (!staff && !registered) return res.status(403).json({ error: 'Only registered participants can access room details.' });
  if (!staff && (!match.credentials_release_at || Date.now() < new Date(match.credentials_release_at).getTime())) {
    return res.status(403).json({ error: 'Room details are not available yet.' });
  }
  audit(req.user.id, 'view_room_credentials', 'match', match.id);
  res.json({ roomId: match.room_id || null, roomPassword: match.room_password || null });
});

app.post('/api/tournaments', requireAuth, requireRole('admin'), (req, res) => {
  const b = req.body || {};
  const name = safeText(b.name, 100), mode = safeText(b.mode, 10);
  const startsAt = safeText(b.startsAt, 40), deadline = safeText(b.registrationDeadline, 40);
  const slots = Number(b.slotLimit);
  if (name.length < 3 || !['Solo','Duo','Squad'].includes(mode) || !Number.isInteger(slots) || slots < 1 || !Number.isFinite(Date.parse(startsAt)) || !Number.isFinite(Date.parse(deadline))) {
    return res.status(400).json({ error: 'Provide a tournament name, valid mode, dates, and positive slot limit.' });
  }
  const result = db.prepare(`INSERT INTO tournaments(name,description,mode,map_name,starts_at,registration_deadline,slot_limit,entry_fee_paise,prize_pool_paise,rules,status,created_by)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(name, safeText(b.description, 2000), mode, safeText(b.mapName, 40) || 'Bermuda', startsAt, deadline, slots,
      Math.max(0, Number(b.entryFeePaise) || 0), Math.max(0, Number(b.prizePoolPaise) || 0), safeText(b.rules, 4000), 'Open', req.user.id);
  audit(req.user.id, 'create_tournament', 'tournament', Number(result.lastInsertRowid));
  res.status(201).json({ id: Number(result.lastInsertRowid) });
});

app.post('/api/matches', requireAuth, requireRole('admin'), (req, res) => {
  const b = req.body || {};
  if (!Number.isInteger(Number(b.tournamentId)) || !safeText(b.roundName, 80) || !Number.isFinite(Date.parse(b.startsAt))) return res.status(400).json({ error: 'Tournament, round name, and valid start time are required.' });
  const result = db.prepare(`INSERT INTO matches(tournament_id,round_name,starts_at,map_name,room_id,room_password,credentials_release_at)
    VALUES(?,?,?,?,?,?,?)`).run(Number(b.tournamentId), safeText(b.roundName,80), b.startsAt, safeText(b.mapName,40)||'Bermuda',
      safeText(b.roomId,80)||null, safeText(b.roomPassword,80)||null, b.credentialsReleaseAt ? safeText(b.credentialsReleaseAt,40) : null);
  audit(req.user.id, 'create_match', 'match', Number(result.lastInsertRowid));
  res.status(201).json({ id: Number(result.lastInsertRowid) });
});

app.post('/api/results', requireAuth, (req, res) => {
  const matchId = Number(req.body.matchId), placement = Number(req.body.placement), kills = Number(req.body.kills);
  if (!Number.isInteger(matchId) || !Number.isInteger(placement) || placement < 1 || placement > 100 || !Number.isInteger(kills) || kills < 0 || kills > 100) return res.status(400).json({ error: 'Enter a valid match, placement, and kill count.' });
  const match = db.prepare('SELECT * FROM matches WHERE id=?').get(matchId);
  if (!match) return res.status(404).json({ error: 'Match not found.' });
  if (!db.prepare('SELECT 1 FROM registrations WHERE tournament_id=? AND user_id=?').get(match.tournament_id, req.user.id)) return res.status(403).json({ error: 'Register for this tournament before submitting results.' });
  try {
    const r = db.prepare('INSERT INTO result_submissions(match_id,user_id,placement,kills,evidence_url) VALUES(?,?,?,?,?)')
      .run(matchId, req.user.id, placement, kills, safeText(req.body.evidenceUrl, 500));
    res.status(201).json({ id: Number(r.lastInsertRowid), status: 'Pending' });
  } catch (e) { res.status(409).json({ error: 'A result has already been submitted for this match.' }); }
});
app.get('/api/leaderboard', (_req, res) => {
  const rows = db.prepare(`SELECT u.username, u.in_game_name, SUM(rs.kills) kills,
    COUNT(rs.id) matches_played,
    SUM(rs.kills + CASE rs.placement WHEN 1 THEN 12 WHEN 2 THEN 9 WHEN 3 THEN 6 WHEN 4 THEN 4 WHEN 5 THEN 2 WHEN 6 THEN 1 ELSE 0 END) total_points
    FROM result_submissions rs JOIN users u ON u.id=rs.user_id
    WHERE rs.status='Approved' GROUP BY u.id ORDER BY total_points DESC,kills DESC LIMIT 100`).all();
  res.json({ leaderboard: rows });
});
app.get('/api/announcements', (_req, res) => res.json({ announcements: db.prepare('SELECT id,title,body,created_at FROM announcements ORDER BY created_at DESC LIMIT 30').all() }));
app.post('/api/support', requireAuth, (req, res) => {
  const category = safeText(req.body.category, 30), subject = safeText(req.body.subject, 120), message = safeText(req.body.message, 3000);
  if (!['account','tournament','result','payment','refund','technical','general'].includes(category) || subject.length < 4 || message.length < 10) return res.status(400).json({ error: 'Choose a category and provide a subject and message.' });
  const r = db.prepare('INSERT INTO support_tickets(user_id,category,subject,message) VALUES(?,?,?,?)').run(req.user.id, category, subject, message);
  res.status(201).json({ id: Number(r.lastInsertRowid), status: 'Open' });
});
app.get('/api/support/mine', requireAuth, (req, res) => res.json({ tickets: db.prepare('SELECT id,category,subject,message,status,created_at FROM support_tickets WHERE user_id=? ORDER BY created_at DESC').all(req.user.id) }));

// Create the first admin only when the database has no users. Configure ADMIN_EMAIL and ADMIN_PASSWORD before first start.
if (db.prepare('SELECT COUNT(*) n FROM users').get().n === 0 && process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
  const email = process.env.ADMIN_EMAIL.toLowerCase();
  if (validEmail(email) && process.env.ADMIN_PASSWORD.length >= 12) {
    const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12);
    db.prepare("INSERT INTO users(email,username,password_hash,role) VALUES(?,?,?,'admin')").run(email, 'FireBattleAdmin', hash);
    console.log('Initial admin account created from environment configuration.');
  } else {
    console.warn('Admin bootstrap skipped: set a valid ADMIN_EMAIL and ADMIN_PASSWORD of at least 12 characters.');
  }
}

app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});

app.listen(PORT, () => console.log(`Fire Battle running at http://localhost:${PORT}`));
