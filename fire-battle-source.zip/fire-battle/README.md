# Fire Battle

A mobile-first Free Fire community tournament platform starter built with HTML/CSS/JavaScript, Express, and SQLite. This repository contains working Phase 1 foundations and selected Phase 2–4 endpoints. It is not yet a complete production esports platform.

## Included in this starter

- Responsive dark esports UI with fire/orange accents.
- Tournament browsing, filters, detail dialogs, slots, and registration.
- Account registration/login with bcrypt password hashes and HTTP-only session cookie.
- SQLite persistence for users, tournaments, registrations, matches, results, announcements, support tickets, and audit logs.
- Server-side role checks on tournament/match creation.
- Participant-only room credential endpoint with server-side release-time checks.
- Result submission endpoint; only approved submissions count toward leaderboard.
- Support ticket creation and owner-only ticket listing.
- PWA manifest, icon, service worker, and Android home-screen installation support.
- `.env.example` and this setup guide.

## Stack and trade-offs

- **Plain HTML/CSS/JS:** quick to load and easy to edit from a phone. It has less structure than React but avoids a build step.
- **Node.js + Express:** handles protected operations server-side.
- **SQLite + better-sqlite3:** persistent database stored in `data/fire-battle.sqlite`; excellent for a single server. For multi-instance or high-traffic deployment, migrate to PostgreSQL.
- **PWA:** players can add the website to their Android home screen. This is not a native APK or automatic Google Play Store release.

## Requirements

Install Node.js 20 or newer on a computer or a supported terminal environment. SQLite's native dependency may need a compiler/build tools on some platforms. On Android, a terminal environment such as Termux may work, but setup and native package support vary.

## Run locally

1. Extract the ZIP.
2. Open a terminal in the extracted `fire-battle` folder.
3. Install Node.js 20+.
4. Copy `.env.example` to `.env` and set a unique `SESSION_SECRET`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD` (at least 12 characters).
5. Install dependencies and start the server:

   ```bash
   npm install
   npm start
   ```

6. Open `http://localhost:3000` in a browser.

The server loads `.env` using `dotenv` for local development. On hosting providers, set environment variables in the provider dashboard instead of uploading secrets.

The initial admin account is created only if the database has no users and valid `ADMIN_EMAIL` / `ADMIN_PASSWORD` environment variables are present at first startup. If you started without these values and already created a player, configure admin provisioning manually before deployment; do not promote a user through an unprotected public endpoint.

## Quick API overview

- `GET /api/health`
- `GET /api/me`
- `POST /api/auth/register` `{ "email": "...", "username": "...", "password": "10+ characters" }`
- `POST /api/auth/login` `{ "email": "...", "password": "..." }`
- `POST /api/auth/logout`
- `GET /api/tournaments?mode=Squad&status=Open`
- `GET /api/tournaments/:id`
- `POST /api/tournaments/:id/register` (logged in)
- `GET /api/me/registrations` (logged in)
- `POST /api/tournaments` (admin only)
- `POST /api/matches` (admin only)
- `GET /api/matches/:id/room` (registered participant after release, or moderator/admin)
- `POST /api/results` (logged-in registered participant)
- `GET /api/leaderboard`
- `GET /api/announcements`
- `POST /api/support` (logged in)
- `GET /api/support/mine` (logged in)

All JSON API errors return an `error` field. All room credentials must be created only for real matches by authorized staff; no real credentials are included in the repository.

## Deployment

1. Choose a Node.js host that supports persistent disk storage and SQLite, or use PostgreSQL if the host has ephemeral filesystems/multiple instances.
2. Upload the project or connect a Git repository.
3. Set `NODE_ENV=production`, `PORT` as required by the host, a long random `SESSION_SECRET`, and admin bootstrap variables.
4. Ensure the `data/` directory persists across restarts and deployments. If not, SQLite data can be lost.
5. Deploy behind HTTPS. Secure cookies are enabled when `NODE_ENV=production`.
6. Test account registration, login, registration, and room access rules before inviting players.
7. Add a custom domain only if desired; domains and some hosting/database/storage features may cost money.

A free host may sleep, limit bandwidth/storage, or remove persistent disks. No provider is guaranteed to host a real-time tournament platform forever at no cost.

## Android installation (PWA)

After deployment on HTTPS, open the website in Chrome on Android. Use the browser menu and choose **Install app** or **Add to Home screen** if offered. A PWA is not a native APK. The service worker caches the shell, but API-backed data still requires a connection.

## Backup and restore

Stop the server, copy `data/fire-battle.sqlite` to a safe private location, then restart. Keep backups private because they contain account data. To restore, stop the server and put the backup file back in `data/`. Never commit the `data/` folder to source control.

## Important security and completeness notes

This is a starter, not a fully audited production platform. The in-memory session store is cleared on restart and does not work across multiple instances; replace it with persistent server-side sessions before production. Add CSRF protection and stricter origin controls before public launch. Admin UI workflows, team roster management/invitations, match administration UI, result review UI, configurable per-tournament scoring/tie-breaks, push/email delivery, password reset, payment provider/webhooks, refunds, prize payouts, special events, reports/appeals, moderation screens, maintenance controls, legal-policy editing, and automated backup scheduling are not fully implemented yet. Live payments and payouts are intentionally not enabled.

The default leaderboard scoring uses 1 point per kill plus placement points of 1st=12, 2nd=9, 3rd=6, 4th=4, 5th=2, 6th=1. Per-tournament configuration and advanced team scoring are not implemented in this starter. Duo/Squad team registration currently has a basic team-name field but not full roster management.

## Tests

Run `npm test`. The current project has no automated test suite yet, so this command will report zero tests rather than prove workflows. Before production, add and run the test cases listed in the original Fire Battle brief, especially role authorization, race-safe slot capacity, credential release/access, score review, support privacy, and deployment persistence.

## Free Fire trademark

Fire Battle is an independent community project and is not affiliated with Garena. Do not use copyrighted game art or imply official endorsement without permission.
