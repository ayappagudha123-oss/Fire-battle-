const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

test('project includes core server and client entrypoints', () => {
  const root = path.join(__dirname, '..');
  for (const file of ['src/server.js','src/db.js','public/index.html','public/app.js','public/styles.css','README.md','.env.example']) {
    assert.ok(fs.existsSync(path.join(root, file)), `missing ${file}`);
  }
});

test('payment integrations are not enabled by default', () => {
  const server = fs.readFileSync(path.join(__dirname, '..', 'src', 'server.js'), 'utf8');
  assert.match(server, /Payment statuses|payments/i.test(server) ? /Payment statuses|payments/i : /room credentials/);
  assert.doesNotMatch(server, /app\.post\(['"]\/api\/payments\/charge/);
});
