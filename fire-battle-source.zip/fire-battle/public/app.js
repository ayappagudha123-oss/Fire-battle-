const $ = (s) => document.querySelector(s);
let currentUser = null;
let tournaments = [];
let selectedTournament = null;
let authMode = 'login';
let toastTimer;

function escapeHtml(value='') {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function money(paise) {
  const n = Number(paise || 0) / 100;
  return n === 0 ? 'Free' : '₹' + n.toLocaleString('en-IN', {maximumFractionDigits:2});
}
function dateText(value) {
  if (!value) return 'Date to be announced';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return 'Date to be announced';
  return d.toLocaleString('en-IN', {day:'numeric',month:'short',year:'numeric',hour:'numeric',minute:'2-digit'});
}
function showToast(message) {
  const node = $('#toast'); node.textContent = message; node.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => node.classList.remove('show'), 3000);
}
async function api(url, options={}) {
  const response = await fetch(url, { credentials:'same-origin', ...options, headers:{'Content-Type':'application/json', ...(options.headers||{})} });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `Request failed (${response.status})`);
  return body;
}
function statusClass(status) {
  return ['Live','Completed','Cancelled','Upcoming'].includes(status) ? status.toLowerCase() : '';
}
function tournamentCard(t) {
  const available = Math.max(0, Number(t.slot_limit) - Number(t.registered_count));
  const canRegister = t.status === 'Open' && available > 0 && Date.parse(t.registration_deadline) > Date.now();
  return `<article class="tournament-card">
    <div class="card-art"><span class="status ${statusClass(t.status)}">${escapeHtml(t.status)}</span><span class="mode-emblem" aria-hidden="true">${t.mode==='Solo'?'🎯':t.mode==='Duo'?'⚔️':'🔥'}</span></div>
    <div class="card-body"><h3>${escapeHtml(t.name)}</h3><p>${escapeHtml(t.description || `${t.mode} tournament • ${t.map_name || 'Bermuda'}`)}</p>
    <div class="card-meta"><div><span>MODE / MAP</span><b>${escapeHtml(t.mode)} · ${escapeHtml(t.map_name)}</b></div><div><span>PRIZE POOL</span><b>${money(t.prize_pool_paise)}</b></div><div><span>STARTS</span><b>${escapeHtml(dateText(t.starts_at))}</b></div><div><span>ENTRY</span><b>${money(t.entry_fee_paise)}</b></div></div>
    <div class="card-footer"><small>${available} / ${t.slot_limit} slots left</small><button class="button ${canRegister?'button-fire':'button-outline'}" data-detail="${t.id}">${canRegister?'View & join':'View details'} ↗</button></div></div>
  </article>`;
}
async function loadTournaments() {
  const grid = $('#tournamentGrid'); grid.innerHTML = '<div class="loading-card">Loading tournaments…</div>';
  try {
    const mode = $('#modeFilter').value, status = $('#statusFilter').value;
    const query = new URLSearchParams(); if (mode) query.set('mode',mode); if (status) query.set('status',status);
    const data = await api('/api/tournaments?' + query.toString());
    tournaments = data.tournaments;
    renderTournaments();
    $('#statTournaments').textContent = tournaments.length;
    $('#statOpen').textContent = tournaments.filter(t=>t.status==='Open').reduce((sum,t)=>sum+Math.max(0,t.slot_limit-t.registered_count),0);
    $('#tournamentMessage').textContent = tournaments.length ? `${tournaments.length} tournament${tournaments.length===1?'':'s'} found.` : 'No tournaments match these filters yet. Check back soon.';
  } catch (e) { grid.innerHTML = `<div class="empty-card">${escapeHtml(e.message)} <button class="button button-outline" id="retryLoad">Try again</button></div>`; }
}
function renderTournaments() {
  const term = $('#searchInput').value.trim().toLowerCase();
  const filtered = tournaments.filter(t => `${t.name} ${t.description} ${t.mode} ${t.map_name}`.toLowerCase().includes(term));
  $('#tournamentGrid').innerHTML = filtered.length ? filtered.map(tournamentCard).join('') : '<div class="empty-card">No tournaments found. Try another search.</div>';
}
async function loadLeaderboard() {
  try {
    const data = await api('/api/leaderboard');
    const body = $('#leaderboardBody');
    body.innerHTML = data.leaderboard.length ? data.leaderboard.map((p,i)=>`<tr><td class="rank">#${i+1}</td><td><b>${escapeHtml(p.in_game_name || p.username)}</b></td><td>${p.matches_played}</td><td>${p.kills}</td><td><b>${p.total_points}</b></td></tr>`).join('') : '<tr><td colspan="5" class="empty">No approved results yet. The leaderboard will appear after reviewed matches.</td></tr>';
  } catch { $('#leaderboardBody').innerHTML = '<tr><td colspan="5" class="empty">Leaderboard could not be loaded.</td></tr>'; }
}
async function loadMe() {
  try { const data = await api('/api/me'); currentUser = data.user; }
  catch { currentUser = null; }
  const authButton = $('#authButton'), panel = $('#profilePanel');
  if (currentUser) {
    authButton.textContent = 'Logout';
    panel.innerHTML = `<span class="profile-icon">🔥</span><div><b>${escapeHtml(currentUser.username)}</b><p class="muted">${escapeHtml(currentUser.email)} · ${escapeHtml(currentUser.role)}</p></div><button class="button button-outline" id="myRegistrations">My tournaments</button><button class="button button-outline" id="logoutButton">Logout</button>`;
  } else {
    authButton.textContent = 'Login';
    panel.innerHTML = '<span class="profile-icon">👤</span><div><b>Guest player</b><p class="muted">Sign in or create an account to get started.</p></div><button class="button button-fire" id="profileAuth">Login / Register</button>';
  }
}
function openAuth(mode='login') {
  authMode = mode; updateAuthMode(); $('#authMessage').textContent = ''; $('#authDialog').showModal();
}
function updateAuthMode() {
  document.querySelectorAll('[data-auth-mode]').forEach(b=>b.classList.toggle('active',b.dataset.authMode===authMode));
  $('#authTitle').textContent = authMode==='login' ? 'Welcome back' : 'Create your account';
  $('#usernameWrap').hidden = authMode==='login';
  $('#authForm [name=username]').required = authMode==='register';
  $('#authForm [name=password]').autocomplete = authMode==='login' ? 'current-password' : 'new-password';
  $('#authForm button[type=submit]').textContent = authMode==='login' ? 'Login' : 'Create account';
}
function openDetails(id) {
  selectedTournament = tournaments.find(t=>Number(t.id)===Number(id));
  if (!selectedTournament) return;
  const t=selectedTournament, available=Math.max(0,t.slot_limit-t.registered_count);
  $('#detailTitle').textContent=t.name;
  $('#detailBody').innerHTML=`<p class="detail-description">${escapeHtml(t.description||'Join the tournament and compete fairly. Read all rules before registering.')}</p>
    <div class="detail-stats"><div class="detail-stat"><span>MODE</span><b>${escapeHtml(t.mode)}</b></div><div class="detail-stat"><span>MAP</span><b>${escapeHtml(t.map_name)}</b></div><div class="detail-stat"><span>START TIME</span><b>${escapeHtml(dateText(t.starts_at))}</b></div><div class="detail-stat"><span>REGISTRATION CLOSES</span><b>${escapeHtml(dateText(t.registration_deadline))}</b></div><div class="detail-stat"><span>ENTRY FEE</span><b>${money(t.entry_fee_paise)}</b></div><div class="detail-stat"><span>PRIZE POOL</span><b>${money(t.prize_pool_paise)}</b></div><div class="detail-stat"><span>SLOTS</span><b>${available} available of ${t.slot_limit}</b></div><div class="detail-stat"><span>STATUS</span><b>${escapeHtml(t.status)}</b></div></div>
    <p class="detail-description"><b>Rules:</b><br>${escapeHtml(t.rules||'Tournament rules will be announced by the organizer.')}</p>`;
  const button=$('#registerButton');
  const open=t.status==='Open' && available>0 && Date.parse(t.registration_deadline)>Date.now();
  button.hidden=!open; button.disabled=false; button.textContent='Register for tournament';
  $('#detailMessage').textContent='';
  $('#detailDialog').showModal();
}
async function registerSelected() {
  if (!currentUser) { $('#detailDialog').close(); openAuth('login'); showToast('Log in to register for a tournament.'); return; }
  const button=$('#registerButton'); button.disabled=true; button.textContent='Registering…';
  try {
    const data=await api(`/api/tournaments/${selectedTournament.id}/register`,{method:'POST',body:JSON.stringify({teamName:''})});
    $('#detailMessage').textContent=data.message; button.hidden=true; await loadTournaments(); showToast(data.message);
  } catch(e) { $('#detailMessage').textContent=e.message; }
  finally { if (!button.hidden) {button.disabled=false;button.textContent='Register for tournament';} }
}
async function submitAuth(event) {
  event.preventDefault(); const form=event.currentTarget, values=Object.fromEntries(new FormData(form).entries());
  $('#authMessage').textContent='Please wait…';
  try {
    const endpoint=authMode==='login'?'/api/auth/login':'/api/auth/register';
    const data=await api(endpoint,{method:'POST',body:JSON.stringify(values)});
    currentUser=data.user; $('#authDialog').close(); form.reset(); await loadMe(); showToast(`Welcome${currentUser?.username?' '+currentUser.username:''}!`);
  } catch(e) { $('#authMessage').textContent=e.message; }
}
async function logout() {
  try { await api('/api/auth/logout',{method:'POST',body:'{}'}); currentUser=null; await loadMe(); showToast('You are logged out.'); }
  catch(e) { showToast(e.message); }
}
async function showMyRegistrations() {
  try {
    const data=await api('/api/me/registrations');
    $('#detailTitle').textContent='My tournaments';
    $('#detailBody').innerHTML=data.registrations.length?data.registrations.map(r=>`<div class="detail-stat"><b>${escapeHtml(r.name)}</b><p class="muted">${escapeHtml(r.mode)} · ${escapeHtml(dateText(r.starts_at))} · ${escapeHtml(r.status)}</p></div>`).join(''):'<p class="muted">You have not registered for any tournaments yet.</p>';
    $('#registerButton').hidden=true; $('#detailMessage').textContent=''; $('#detailDialog').showModal();
  } catch(e) { showToast(e.message); }
}
async function submitSupport(event) {
  event.preventDefault();
  if (!currentUser) { $('#supportDialog').close(); openAuth('login'); showToast('Log in to contact support.'); return; }
  const form=event.currentTarget, values=Object.fromEntries(new FormData(form).entries()); $('#supportMessage').textContent='Sending…';
  try { const data=await api('/api/support',{method:'POST',body:JSON.stringify(values)}); $('#supportMessage').textContent=`Ticket #${data.id} created. Status: ${data.status}.`; form.reset(); showToast('Support ticket submitted.'); }
  catch(e) { $('#supportMessage').textContent=e.message; }
}
document.addEventListener('click', async event => {
  const detail=event.target.closest('[data-detail]');
  if (detail) openDetails(detail.dataset.detail);
  if (event.target.id==='retryLoad') loadTournaments();
  if (event.target.closest('#authButton')) { if(currentUser) logout(); else openAuth('login'); }
  if (event.target.closest('#heroJoin')||event.target.closest('#profileAuth')) openAuth('register');
  if (event.target.closest('#registerButton')) registerSelected();
  if (event.target.closest('#refreshButton')) { loadTournaments(); loadLeaderboard(); }
  if (event.target.closest('#logoutButton')) logout();
  if (event.target.closest('#myRegistrations')) showMyRegistrations();
  if (event.target.closest('#supportButton')) { $('#supportMessage').textContent=''; $('#supportDialog').showModal(); }
  const tab=event.target.closest('[data-auth-mode]'); if(tab){authMode=tab.dataset.authMode;updateAuthMode();}
});
$('#authForm').addEventListener('submit',submitAuth);
$('#supportForm').addEventListener('submit',submitSupport);
$('#modeFilter').addEventListener('change',loadTournaments);
$('#statusFilter').addEventListener('change',loadTournaments);
$('#searchInput').addEventListener('input',renderTournaments);
$('#year').textContent=new Date().getFullYear();
loadTournaments(); loadLeaderboard(); loadMe();
if ('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
